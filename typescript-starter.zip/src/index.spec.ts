import { expect } from 'chai';
import { MyProject } from './index';

describe('MyProject', (): void => {

  describe('myMethod()', (): void => {

    it('should return "Hello 5"', (): void => {
      expect(MyProject.myMethod('Hello ', 5)).to.equal('Hello 5');
    });

  });
  
});
