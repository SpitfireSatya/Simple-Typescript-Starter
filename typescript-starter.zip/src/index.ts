
/**
 * Sample TypeDoc comment for class MyProject
 */
export class MyProject {

  /**
   * sample TypeDoc comment for my method.
   * Params and Returns will be auto-generated
   */
  public static myMethod = (arg1: string, arg2: number): string => {
    return 'It works!!';
  }

}

console.log(MyProject.myMethod('', 0));
